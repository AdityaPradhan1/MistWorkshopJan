# Packet-Sniffing-Python-MIST-Workshop
Network Sniffing using Python
Run the sniffer.py code with root privileges i.e through administrator command prompt in Windows as : python sniffer.py
